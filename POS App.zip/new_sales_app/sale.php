<?php $page_heading = "Sale Products";?>
<?php include 'header.php';?>

<section class="body">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12 ">
                <div class="search">
                   <form>
                       <input type="search" placeholder="Search by code, Name, Rate...">
                    </form>
                </div>
            </div>
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="product-list">
                    <div class="col-md-3 col-sm-3 col-xs-3 n-pad">
                        <img src="images/p1.jpg" class=" img-responsive">
                    </div>
                    <div class="col-md-7 col-sm-7 col-xs-7">
                        <p class="p-name">(EC098) Blue Casual Shoes For Me</p>
                        <p class="p-details">Weinbrenner brings forth these blue casual shoes that are a timeless staple that will never step out of vogue. Featuring a PU upper and phylon outosle, these lace-ups are highly durable and will keep your feet at utmost ease all day long.</p>
                        <p class="price-tag"><span class="price">1692 TK</span>&nbsp;, <span class="s-quantity">10 pcs</span></p>
                    </div>
                    <div class="col-md-2 col-sm-2 col-xs-2 n-pad s-p">
                        <div class="col-md-12 col-sm-12 col-xs-12 n-pad"><p class="up-arrow"><i class="fa fa-chevron-up"></i></p></div>
                        <div class="col-md-12 col-sm-12 col-xs-12 n-pad"><p class="price-p">0</p></div>
                        <div class="col-md-12 col-sm-12 col-xs-12 n-pad"><p class="down-arrow"><i class="fa fa-chevron-down"></i></p></div>
                    </div>
                    <div style="clear: both;"></div>
                </div>
                <div class="product-list">
                    <div class="col-md-3 col-sm-3 col-xs-3 n-pad">
                        <img src="images/p3.jpg" class=" img-responsive">
                    </div>
                    <div class="col-md-7 col-sm-7 col-xs-7">
                        <p class="p-name">(EC098) Blue Casual Shoes For Me</p>
                        <p class="p-details">Weinbrenner brings forth these blue casual shoes that are a timeless staple that will never step out of vogue. Featuring a PU upper and phylon outosle, these lace-ups are highly durable and will keep your feet at utmost ease all day long.</p>
                        <p class="price-tag"><span class="price">1692 TK</span>&nbsp;, <span class="s-quantity">10 pcs</span></p>
                    </div>
                    <div class="col-md-2 col-sm-2 col-xs-2 n-pad s-p">
                        <div class="col-md-12 col-sm-12 col-xs-12 n-pad"><p class="up-arrow"><i class="fa fa-chevron-up"></i></p></div>
                        <div class="col-md-12 col-sm-12 col-xs-12 n-pad"><p class="price-p">0</p></div>
                        <div class="col-md-12 col-sm-12 col-xs-12 n-pad"><p class="down-arrow"><i class="fa fa-chevron-down"></i></p></div>
                    </div>
                    <div style="clear: both;"></div>
                </div>
                <div class="product-list">
                    <div class="col-md-3 col-sm-3 col-xs-3 n-pad">
                        <img src="images/p2.jpg" class=" img-responsive">
                    </div>
                    <div class="col-md-7 col-sm-7 col-xs-7">
                        <p class="p-name">(EC098) Blue Casual Shoes For Me</p>
                        <p class="p-details">Weinbrenner brings forth these blue casual shoes that are a timeless staple that will never step out of vogue. Featuring a PU upper and phylon outosle, these lace-ups are highly durable and will keep your feet at utmost ease all day long.</p>
                        <p class="price-tag"><span class="price">1692 TK</span>&nbsp;, <span class="s-quantity">10 pcs</span></p>
                    </div>
                    <div class="col-md-2 col-sm-2 col-xs-2 n-pad s-p">
                        <div class="col-md-12 col-sm-12 col-xs-12 n-pad"><p class="up-arrow"><i class="fa fa-chevron-up"></i></p></div>
                        <div class="col-md-12 col-sm-12 col-xs-12 n-pad"><p class="price-p">0</p></div>
                        <div class="col-md-12 col-sm-12 col-xs-12 n-pad"><p class="down-arrow"><i class="fa fa-chevron-down"></i></p></div>
                    </div>
                    <div style="clear: both;"></div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'sales_footer.php' ;?>
