<?php $page_heading = "BDSoft IT Solutions";?>
<?php include 'header.php';?>

    <div class="container-fluid"> 
           <div class="row">
                <div class="col-xs-6 col-sm-6 col">
                    <a href="sale.php" class="list_style">
                        <div class="column b-1">

                            <center><img src="images/cart.png" "="" class="img-responsive"></center>
                            <h5>New Order</h5>
                            <span class="count">5</span>
                        </div>
                    </a>
                </div>
               
                <div class="col-xs-6 col-sm-6 col">
                    <a href="" class="list_style">
                        <div class="column b-3">
                            <center><img src="images/pending_order.png"" "="" class="img-responsive"></center>
                            <h5>Pending Order</h5>
                            <span class="count">2</span>
                        </div>
                    </a>
                </div>
                <div class="col-xs-6 col-sm-6 col">
                    <a href="sale.php" class="list_style">
                        <div class="column b-1">
                            <center><img src="images/today_delivered.png"" "="" class="img-responsive"></center>
                            <h5>Today Delivered</h5>
                            <span class="count">7</span>
                        </div>
                    </a>
                </div>
                <div class="col-xs-6 col-sm-6 col">
                    <a href="" class="list_style">
                        <div class="column b-3">
                            <center><img src="images/collection.png"" "="" class="img-responsive"></center>
                            <h5>Today Collections</h5>
                            <span class="count">৳ 987</span>
                        </div>
                    </a>
                </div>
                <div class="col-xs-6 col-sm-6 col">
                    <a href="" class="list_style">
                        <div class="column b-1-b">
                            <center><img src="images/payment.png"" "="" class="img-responsive"></center>
                            <h5>Payments</h5>
                            <span class="count">৳ 632</span>
                        </div>
                    </a>
                </div>
                <div class="col-xs-6 col-sm-6 col">
                    <a href="" class="list_style">
                        <div class="column b-3-b">
                            <center><img src="images/reorderlevel.png"" "="" class="img-responsive"></center>
                            <h5>Low Re-Order Level</h5>
                            <span class="count">3</span>
                        </div>
                    </a>
                </div>
        </div>

    <div class="clearfix"></div>
  </body>
</html>
