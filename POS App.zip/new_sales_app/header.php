<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?=$page_heading?></title>
    <link href="css/bootstrap.min.css" rel="stylesheet"/>
    <link rel="stylesheet" href="css/style.css"/>
    <link rel="stylesheet" href="css/jquery-ui.min.css"/>
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=Ubuntu" rel="stylesheet">
  </head>

  <body>
    <div class="top_fixed col-md-12 col-sm-12-col-xs-12" id="title">
        <h4>
                <div id="mySidenav" class="sidenav">
                    <div class="user_portion">
                        <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>

                        <div class="user_profile">
                          <center><img src="images/user-icon.png"></center>
                          <h4 class="user_name">Md. Shahadat Hossain</h4>
                          <h4 class="user_mobile">+8801682961926</h4>
                        </div>
                    </div>
                  
                  <div class="menu">
                      <a href="#">About</a>
                      <a href="#">Services</a>
                      <a href="#">Clients</a>
                      <a href="#">Contact</a>
                  </div>
                  <div class="version">
                      <h4>Version 3.0.1</h4>
                  </div>
                </div>

                <span class="col-md-2 col-sm-2 col-xs-2"  style="font-size:30px;cursor:pointer;margin: 0px 0px 4px 15px;" onclick="openNav()">&#9776; </span>

                <script>
                function openNav() {
                    document.getElementById("mySidenav").style.width = "250px";
                }

                function closeNav() {
                    document.getElementById("mySidenav").style.width = "0";
                }
                </script>
                <span class="col-md-8 col-sm-8 col-xs-8 head-name"><?=$page_heading?></span>
            <a href="">
                <span class="refresh-p col-md-2 col-sm-2 col-xs-2">
                    <i class="fa fa-refresh "></i>
                </span>
            </a>
            <!-- <a href="notification.html">
                <span class="notification">
                    <i class="fa fa-bell"></i><span class="notification-count">1</span>
                </span>
            </a> -->
        </h4>
    </div>
  
    <div class="clearfix"></div>