<?php $page_heading = "Sale Products";?>
<?php include 'header.php';?>

<section class="body">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12 ">
                <div class="product-list-c">
                    <div class="total-amount">
                        <p>৳ 1250</p>
                    </div>
                    <a href="" class="col-sm-6 col-xs-6 confirm-c">Confirm</a>
                    <a href="sale.php" class="col-sm-6 col-xs-6 add_more-c">Add More</a>
                    <div style="clear: both;"></div>
                </div>
            </div>
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="product-list-c">
                    <div class="col-md-1 col-sm-1 col-xs-1 n-pad">
                        <div class="col-md-12 col-sm-12 col-xs-12 n-pad"><p class="up-arrow-c"><i class="fa fa-chevron-up"></i></p></div>
                        <div class="col-md-12 col-sm-12 col-xs-12 n-pad"><p class="price-p">1</p></div>
                        <div class="col-md-12 col-sm-12 col-xs-12 n-pad"><p class="down-arrow-c"><i class="fa fa-chevron-down"></i></p></div>
                    </div>
                    <div class="col-md-7 col-sm-7 col-xs-7 n-pad p-dt">
                        <p class="p-name-c">(EC098) Blue Casual Shoes</p>
                        <p class="price-tag"><span class="price">1000 TK / PCS</span></p>
                    </div>
                    
                    <div class="col-md-3 col-sm-3 col-xs-3 n-pad">
                        <p class="price-p prc-p">৳ 1000</p>
                    </div>
                    <div class="col-md-1 col-sm-1 col-xs-1 n-pad rem">
                        <i class="fa fa-remove"></i>
                    </div>
                    <div style="clear: both;"></div>
                </div>

                <div class="product-list-c">
                    <div class="col-md-1 col-sm-1 col-xs-1 n-pad">
                        <div class="col-md-12 col-sm-12 col-xs-12 n-pad"><p class="up-arrow-c"><i class="fa fa-chevron-up"></i></p></div>
                        <div class="col-md-12 col-sm-12 col-xs-12 n-pad"><p class="price-p">1</p></div>
                        <div class="col-md-12 col-sm-12 col-xs-12 n-pad"><p class="down-arrow-c"><i class="fa fa-chevron-down"></i></p></div>
                    </div>
                    <div class="col-md-7 col-sm-7 col-xs-7 n-pad p-dt">
                        <p class="p-name-c">(EC098) Blue Casual Shoes</p>
                        <p class="price-tag"><span class="price">1000 TK / PCS</span></p>
                    </div>
                    
                    <div class="col-md-3 col-sm-3 col-xs-3 n-pad">
                        <p class="price-p prc-p">৳ 1000</p>
                    </div>
                    <div class="col-md-1 col-sm-1 col-xs-1 n-pad rem">
                        <i class="fa fa-remove"></i>
                    </div>
                    <div style="clear: both;"></div>
                </div>

                <div class="product-list-c">
                    <div class="col-md-1 col-sm-1 col-xs-1 n-pad">
                        <div class="col-md-12 col-sm-12 col-xs-12 n-pad"><p class="up-arrow-c"><i class="fa fa-chevron-up"></i></p></div>
                        <div class="col-md-12 col-sm-12 col-xs-12 n-pad"><p class="price-p">1</p></div>
                        <div class="col-md-12 col-sm-12 col-xs-12 n-pad"><p class="down-arrow-c"><i class="fa fa-chevron-down"></i></p></div>
                    </div>
                    <div class="col-md-7 col-sm-7 col-xs-7 n-pad p-dt">
                        <p class="p-name-c">(EC098) Blue Casual Shoes</p>
                        <p class="price-tag"><span class="price">1000 TK / PCS</span></p>
                    </div>
                    
                    <div class="col-md-3 col-sm-3 col-xs-3 n-pad">
                        <p class="price-p prc-p">৳ 1000</p>
                    </div>
                    <div class="col-md-1 col-sm-1 col-xs-1 n-pad rem">
                        <i class="fa fa-remove"></i>
                    </div>
                    <div style="clear: both;"></div>
                </div>

                <div class="product-list-c">
                    <div class="col-md-1 col-sm-1 col-xs-1 n-pad">
                        <div class="col-md-12 col-sm-12 col-xs-12 n-pad"><p class="up-arrow-c"><i class="fa fa-chevron-up"></i></p></div>
                        <div class="col-md-12 col-sm-12 col-xs-12 n-pad"><p class="price-p">1</p></div>
                        <div class="col-md-12 col-sm-12 col-xs-12 n-pad"><p class="down-arrow-c"><i class="fa fa-chevron-down"></i></p></div>
                    </div>
                    <div class="col-md-7 col-sm-7 col-xs-7 n-pad p-dt">
                        <p class="p-name-c">(EC098) Blue Casual Shoes</p>
                        <p class="price-tag"><span class="price">1000 TK / PCS</span></p>
                    </div>
                    
                    <div class="col-md-3 col-sm-3 col-xs-3 n-pad">
                        <p class="price-p prc-p">৳ 1000</p>
                    </div>
                    <div class="col-md-1 col-sm-1 col-xs-1 n-pad rem">
                        <i class="fa fa-remove"></i>
                    </div>
                    <div style="clear: both;"></div>
                </div>

                <div class="product-list-c">
                    <div class="col-md-1 col-sm-1 col-xs-1 n-pad">
                        <div class="col-md-12 col-sm-12 col-xs-12 n-pad"><p class="up-arrow-c"><i class="fa fa-chevron-up"></i></p></div>
                        <div class="col-md-12 col-sm-12 col-xs-12 n-pad"><p class="price-p">1</p></div>
                        <div class="col-md-12 col-sm-12 col-xs-12 n-pad"><p class="down-arrow-c"><i class="fa fa-chevron-down"></i></p></div>
                    </div>
                    <div class="col-md-7 col-sm-7 col-xs-7 n-pad p-dt">
                        <p class="p-name-c">(EC098) Blue Casual Shoes</p>
                        <p class="price-tag"><span class="price">1000 TK / PCS</span></p>
                    </div>
                    
                    <div class="col-md-3 col-sm-3 col-xs-3 n-pad">
                        <p class="price-p prc-p">৳ 1000</p>
                    </div>
                    <div class="col-md-1 col-sm-1 col-xs-1 n-pad rem">
                        <i class="fa fa-remove"></i>
                    </div>
                    <div style="clear: both;"></div>
                </div>

                <div class="product-list-c">
                    <div class="col-md-1 col-sm-1 col-xs-1 n-pad">
                        <div class="col-md-12 col-sm-12 col-xs-12 n-pad"><p class="up-arrow-c"><i class="fa fa-chevron-up"></i></p></div>
                        <div class="col-md-12 col-sm-12 col-xs-12 n-pad"><p class="price-p">1</p></div>
                        <div class="col-md-12 col-sm-12 col-xs-12 n-pad"><p class="down-arrow-c"><i class="fa fa-chevron-down"></i></p></div>
                    </div>
                    <div class="col-md-7 col-sm-7 col-xs-7 n-pad p-dt">
                        <p class="p-name-c">(EC098) Blue Casual Shoes</p>
                        <p class="price-tag"><span class="price">1000 TK / PCS</span></p>
                    </div>
                    
                    <div class="col-md-3 col-sm-3 col-xs-3 n-pad">
                        <p class="price-p prc-p">৳ 1000</p>
                    </div>
                    <div class="col-md-1 col-sm-1 col-xs-1 n-pad rem">
                        <i class="fa fa-remove"></i>
                    </div>
                    <div style="clear: both;"></div>
                </div>
                
                
            </div>
        </div>
    </div>
</section>

<?php include 'sales_footer.php' ;?>
