<?php $page_heading = "General Setup";?>
<?php include 'header.php';?>

    <div class="container-fluid"> 
           <div class="row">
                <div class="col-xs-4 col-sm-4 col">
                    <a href="" class="list_style">
                        <div class="column b-1">
                            <center><img src="images/setting.png" "="" class="img-responsive"></center>
                            <h5>Group</h5>
                        </div>
                    </a>
                </div>
               
                <div class="col-xs-4 col-sm-4 col">
                    <a href="" class="list_style">
                        <div class="column b-1">
                            <center><img src="images/products_entry.png"" "="" class="img-responsive"></center>
                            <h5>Category</h5>
                        </div>
                    </a>
                </div>
                <div class="col-xs-4 col-sm-4 col">
                    <a href="" class="list_style">
                        <div class="column b-3">
                            <center><img src="images/purchase.png"" "="" class="img-responsive"></center>
                            <h5>Bank</h5>
                        </div>
                    </a>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-4 col-sm-4 col">
                    <a href="" class="list_style">
                        <div class="column b-1-b">
                            <center><img src="images/collection.png"" "="" class="img-responsive"></center>
                            <h5>Customer</h5>
                        </div>
                    </a>
                </div>
                <div class="col-xs-4 col-sm-4 col">
                    <a href="" class="list_style">
                        <div class="column b-1-b">
                            <center><img src="images/cart.png"" "="" class="img-responsive"></center>
                            <h5>Supplier</h5>
                        </div>
                    </a>
                </div>
                <div class="col-xs-4 col-sm-4 col">
                    <a href="" class="list_style">
                        <div class="column b-3-b">
                            <center><img src="images/payment.png"" "="" class="img-responsive"></center>
                            <h5>Company Info</h5>
                        </div>
                    </a>
                </div>
               
                
            </div>
            
        </div>

<?php include 'footer.php' ;?>
