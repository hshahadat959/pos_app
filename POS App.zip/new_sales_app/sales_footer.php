    <div class="clearfix"></div>
    <div class="footer-icon">
       <div class="container-fluid">
            
            <div class="row">
                <a href="index.php">
                    <div class="col-md-2 col-sm-2 col-xs-2">
                        <center> 
                            <img src="images/home.png" class="img-responsive">
                        </center>
                        
                    </div>
                </a>
                <a href="cart.php">
                    <div class="col-md-2 col-sm-2 col-xs-2">
                        <center>
                            <img src="images/cart1.png" class="img-responsive">
                        </center>
                        <center><span class="messages_count">1</span></center>
                        
                    </div>
                </a>
                <a href="">
                    <div class="col-md-5 col-sm-5 col-xs-5 confirm">
                        <h4>Confirm</h4>
                        

                    </div>
                </a>
                <a href="cart.php">
                    <div class="col-md-3 col-sm-3 col-xs-3 prc">
                        
                        <h4>৳  1250 </h4>
                    </div>
                </a>
                
            </div>
        </div>
    </div>



    
  </body>
</html>