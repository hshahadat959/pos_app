    <div class="clearfix"></div>
    <div class="footer-icon">
       <div class="container-fluid">
            <div class="row">
                <a href="index.php">
                    <div class="col-md-3 col-sm-3 col-xs-3">
                        <center> 
                            <img src="images/home.png" class="img-responsive">
                        </center>
                        
                    </div>
                </a>
                <a href="">
                    <div class="col-md-3 col-sm-3 col-xs-3">
                        <center>
                            <img src="images/cart1.png" class="img-responsive">
                        </center>
                        <center><span class="messages_count">1</span></center>
                        
                    </div>
                </a>
                <a href="">
                    <div class="col-md-3 col-sm-3 col-xs-3">
                        <center>
                            <img src="images/result.png" class="img-responsive">
                        </center>
                        

                    </div>
                </a>
                <a href="">
                    <div class="col-md-3 col-sm-3 col-xs-3">
                        <center>
                            <img src="images/profile.png" class="img-responsive">
                        </center>
                        
                    </div>
                </a>
                
            </div>
        </div>
    </div>



    
  </body>
</html>